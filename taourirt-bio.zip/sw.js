const V='taourirt-v1';
const CORE=['./','index.html','css/style.css','js/app.js','js/cart-animation.js','manifest.webmanifest','icons/icon-192.png','assets/img/logo.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||u.origin!==location.origin||r.headers.has('range')||u.pathname.endsWith('.mp4'))return;
  if(r.mode==='navigate'){e.respondWith(fetch(r).then(x=>{const k=x.clone();caches.open(V).then(c=>c.put(r,k));return x;}).catch(()=>caches.match(r).then(x=>x||caches.match('index.html'))));return;}
  e.respondWith(caches.match(r).then(h=>h||fetch(r).then(x=>{const k=x.clone();caches.open(V).then(c=>c.put(r,k));return x;})));
});
