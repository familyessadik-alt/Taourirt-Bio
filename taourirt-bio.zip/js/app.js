// ===================== الفيديو =====================
(function(){
  const v = document.getElementById('promoVideo');
  const muteBtn = document.getElementById('muteToggleBtn');
  function refresh(){
    muteBtn.innerHTML = v.muted
      ? '<i class="fas fa-volume-up"></i> تشغيل الصوت'
      : '<i class="fas fa-volume-mute"></i> كتم الصوت';
  }
  muteBtn.addEventListener('click', function(){ v.muted = !v.muted; refresh(); if (v.paused) v.play().catch(()=>{}); });
  v.addEventListener('volumechange', refresh);
  refresh();
})();

// ===================== ترجمة متعددة اللغات =====================
const T = {
  ar: { headline: "منتوجات تاوريرت الطبيعية والأصيلة | Taourirt Bio", oil: "زيت الزيتون البكر - منتوج تاوريرت", honey: "عسل طبيعي - منتوج تاوريرت", l1: "1 لتر", l5: "5 لتر", add: "أضف للسلة", cart: "سلة المشتريات", total: "المجموع", name: "الاسم الكامل", phone: "رقم الهاتف", country: "الدولة", city: "المدينة", addr: "العنوان بالتفصيل (الحي، الشارع، رقم المنزل...)", shipping_label: "ثمن التوصيل (حسب الكمية)", confirm: "تأكيد الطلب عبر واتساب", empty: "إفراغ السلة", nav_oil: "زيت الزيتون", nav_honey: "عسل طبيعي", nav_contact: "تواصل معنا", nav_settings: "الإعدادات", contact: "تواصل معنا", wa_direct: "واتساب مباشر", close: "إغلاق", follow: "تابعنا على الشبكات الاجتماعية", empty_msg: "السلة فارغة", settings_title: "الإعدادات", lang_label: "اللغة", save: "حفظ", settings_note: "سيتم حفظ اختيارك تلقائيًا", alert_empty: "⚠️ الرجاء إضافة منتجات للسلة أولاً!", alert_info: "⚠️ الرجاء ملء جميع معلومات التوصيل!", order_title: "🛒 طلب جديد من موقع تاوريرت بيو | Taourirt Bio 🛒", products: "المنتجات", total_label: "المجموع", shipping_msg: "حسب الكمية", n_oil1: "زيت زيتون تاوريرت 1 لتر", n_oil5: "زيت زيتون تاوريرت 5 لتر", n_honey1: "عسل تاوريرت 1 لتر", n_honey5: "عسل تاوريرت 5 لتر", dir: "rtl", lang: "ar" },
  en: { headline: "Authentic Natural Products from Taourirt | Taourirt Bio", oil: "Extra Virgin Olive Oil - Taourirt product", honey: "Natural Honey - Taourirt product", l1: "1 Liter", l5: "5 Liters", add: "Add to cart", cart: "Shopping Cart", total: "Total", name: "Full name", phone: "Phone number", country: "Country", city: "City", addr: "Full address (district, street, house no...)", shipping_label: "Shipping fee (depends on quantity)", confirm: "Confirm order via WhatsApp", empty: "Empty cart", nav_oil: "Olive Oil", nav_honey: "Honey", nav_contact: "Contact", nav_settings: "Settings", contact: "Contact us", wa_direct: "Direct WhatsApp", close: "Close", follow: "Follow us on social media", empty_msg: "Cart is empty", settings_title: "Settings", lang_label: "Language", save: "Save", settings_note: "Your choice is saved automatically", alert_empty: "⚠️ Please add products to the cart first!", alert_info: "⚠️ Please fill in all delivery information!", order_title: "🛒 New order from Taourirt Bio | Taourirt Bio 🛒", products: "Products", total_label: "Total", shipping_msg: "Depends on quantity", n_oil1: "Taourirt Olive Oil 1L", n_oil5: "Taourirt Olive Oil 5L", n_honey1: "Taourirt Honey 1L", n_honey5: "Taourirt Honey 5L", dir: "ltr", lang: "en" },
  fr: { headline: "Produits naturels authentiques de Taourirt | Taourirt Bio", oil: "Huile d'olive vierge extra - produit de Taourirt", honey: "Miel naturel - produit de Taourirt", l1: "1 litre", l5: "5 litres", add: "Ajouter au panier", cart: "Panier", total: "Total", name: "Nom complet", phone: "Numéro de téléphone", country: "Pays", city: "Ville", addr: "Adresse complète (quartier, rue, n°...)", shipping_label: "Frais de livraison (selon la quantité)", confirm: "Confirmer via WhatsApp", empty: "Vider le panier", nav_oil: "Huile d'olive", nav_honey: "Miel", nav_contact: "Contact", nav_settings: "Paramètres", contact: "Contactez-nous", wa_direct: "WhatsApp direct", close: "Fermer", follow: "Suivez-nous sur les réseaux", empty_msg: "Le panier est vide", settings_title: "Paramètres", lang_label: "Langue", save: "Enregistrer", settings_note: "Votre choix est enregistré automatiquement", alert_empty: "⚠️ Veuillez d'abord ajouter des produits au panier!", alert_info: "⚠️ Veuillez remplir toutes les informations de livraison!", order_title: "🛒 Nouvelle commande depuis Taourirt Bio | Taourirt Bio 🛒", products: "Produits", total_label: "Total", shipping_msg: "Selon la quantité", n_oil1: "Huile d'olive de Taourirt 1L", n_oil5: "Huile d'olive de Taourirt 5L", n_honey1: "Miel de Taourirt 1L", n_honey5: "Miel de Taourirt 5L", dir: "ltr", lang: "fr" },
  de: { headline: "Authentische Naturprodukte aus Taourirt | Taourirt Bio", oil: "Natives Olivenöl extra - Produkt aus Taourirt", honey: "Naturhonig - Produkt aus Taourirt", l1: "1 Liter", l5: "5 Liter", add: "In den Warenkorb", cart: "Warenkorb", total: "Gesamt", name: "Vollständiger Name", phone: "Telefonnummer", country: "Land", city: "Stadt", addr: "Vollständige Adresse (Viertel, Straße, Hausnr...)", shipping_label: "Versandkosten (abhängig von der Menge)", confirm: "Per WhatsApp bestätigen", empty: "Warenkorb leeren", nav_oil: "Olivenöl", nav_honey: "Honig", nav_contact: "Kontakt", nav_settings: "Einstellungen", contact: "Kontakt", wa_direct: "Direkt WhatsApp", close: "Schließen", follow: "Folge uns in sozialen Medien", empty_msg: "Warenkorb ist leer", settings_title: "Einstellungen", lang_label: "Sprache", save: "Speichern", settings_note: "Deine Auswahl wird automatisch gespeichert", alert_empty: "⚠️ Bitte zuerst Produkte in den Warenkorb legen!", alert_info: "⚠️ Bitte alle Lieferinformationen ausfüllen!", order_title: "🛒 Neue Bestellung von Taourirt Bio | Taourirt Bio 🛒", products: "Produkte", total_label: "Gesamt", shipping_msg: "Abhängig von der Menge", n_oil1: "Taourirt Olivenöl 1L", n_oil5: "Taourirt Olivenöl 5L", n_honey1: "Taourirt Honig 1L", n_honey5: "Taourirt Honig 5L", dir: "ltr", lang: "de" },
  es: { headline: "Productos naturales auténticos de Taourirt | Taourirt Bio", oil: "Aceite de oliva virgen extra - producto de Taourirt", honey: "Miel natural - producto de Taourirt", l1: "1 litro", l5: "5 litros", add: "Añadir al carrito", cart: "Carrito", total: "Total", name: "Nombre completo", phone: "Número de teléfono", country: "País", city: "Ciudad", addr: "Dirección completa (barrio, calle, n.º...)", shipping_label: "Gastos de envío (según cantidad)", confirm: "Confirmar por WhatsApp", empty: "Vaciar carrito", nav_oil: "Aceite de oliva", nav_honey: "Miel", nav_contact: "Contacto", nav_settings: "Ajustes", contact: "Contáctanos", wa_direct: "WhatsApp directo", close: "Cerrar", follow: "Síguenos en redes", empty_msg: "El carrito está vacío", settings_title: "Ajustes", lang_label: "Idioma", save: "Guardar", settings_note: "Tu elección se guarda automáticamente", alert_empty: "⚠️ ¡Añade productos al carrito primero!", alert_info: "⚠️ ¡Rellena toda la información de entrega!", order_title: "🛒 Nuevo pedido desde Taourirt Bio | Taourirt Bio 🛒", products: "Productos", total_label: "Total", shipping_msg: "Según cantidad", n_oil1: "Aceite de oliva de Taourirt 1L", n_oil5: "Aceite de oliva de Taourirt 5L", n_honey1: "Miel de Taourirt 1L", n_honey5: "Miel de Taourirt 5L", dir: "ltr", lang: "es" },
  ru: { headline: "Натуральные продукты из Таурирта | Taourirt Bio", oil: "Оливковое масло Extra Virgin - продукт Таурирта", honey: "Натуральный мёд - продукт Таурирта", l1: "1 литр", l5: "5 литров", add: "В корзину", cart: "Корзина", total: "Итого", name: "Полное имя", phone: "Номер телефона", country: "Страна", city: "Город", addr: "Полный адрес (район, улица, дом...)", shipping_label: "Стоимость доставки (зависит от количества)", confirm: "Подтвердить через WhatsApp", empty: "Очистить корзину", nav_oil: "Оливковое масло", nav_honey: "Мёд", nav_contact: "Контакты", nav_settings: "Настройки", contact: "Свяжитесь с нами", wa_direct: "WhatsApp напрямую", close: "Закрыть", follow: "Подписывайтесь в соцсетях", empty_msg: "Корзина пуста", settings_title: "Настройки", lang_label: "Язык", save: "Сохранить", settings_note: "Ваш выбор сохраняется автоматически", alert_empty: "⚠️ Сначала добавьте товары в корзину!", alert_info: "⚠️ Заполните все данные для доставки!", order_title: "🛒 Новый заказ с сайта Taourirt Bio | Taourirt Bio 🛒", products: "Товары", total_label: "Итого", shipping_msg: "Зависит от количества", n_oil1: "Оливковое масло Таурирт 1л", n_oil5: "Оливковое масло Таурирт 5л", n_honey1: "Мёд Таурирт 1л", n_honey5: "Мёд Таурирт 5л", dir: "ltr", lang: "ru" },
  zh: { headline: "来自陶里尔特的天然正宗产品 | Taourirt Bio", oil: "特级初榨橄榄油 - 陶里尔特产品", honey: "天然蜂蜜 - 陶里尔特产品", l1: "1 升", l5: "5 升", add: "加入购物车", cart: "购物车", total: "总计", name: "全名", phone: "电话号码", country: "国家", city: "城市", addr: "详细地址（街区、街道、门牌号…）", shipping_label: "运费（根据数量）", confirm: "通过 WhatsApp 确认订单", empty: "清空购物车", nav_oil: "橄榄油", nav_honey: "蜂蜜", nav_contact: "联系", nav_settings: "设置", contact: "联系我们", wa_direct: "WhatsApp 直达", close: "关闭", follow: "在社交媒体关注我们", empty_msg: "购物车为空", settings_title: "设置", lang_label: "语言", save: "保存", settings_note: "您的选择将自动保存", alert_empty: "⚠️ 请先将产品加入购物车！", alert_info: "⚠️ 请填写完整的配送信息！", order_title: "🛒 来自 Taourirt Bio 网站的新订单 🛒", products: "产品", total_label: "总计", shipping_msg: "根据数量", n_oil1: "陶里尔特橄榄油 1L", n_oil5: "陶里尔特橄榄油 5L", n_honey1: "陶里尔特蜂蜜 1L", n_honey5: "陶里尔特蜂蜜 5L", dir: "ltr", lang: "zh" },
  ko: { headline: "타우리르트(Taourirt)의 천연 정품 | Taourirt Bio", oil: "엑스트라 버진 올리브 오일 - 타우리르트 제품", honey: "천연 꿀 - 타우리르트 제품", l1: "1 리터", l5: "5 리터", add: "장바구니에 담기", cart: "장바구니", total: "합계", name: "성명", phone: "전화번호", country: "국가", city: "도시", addr: "상세 주소 (동/구, 도로명, 번지...)", shipping_label: "배송비(수량에 따라 다름)", confirm: "WhatsApp로 주문 확인", empty: "장바구니 비우기", nav_oil: "올리브 오일", nav_honey: "꿀", nav_contact: "연락처", nav_settings: "설정", contact: "문의하기", wa_direct: "WhatsApp 바로가기", close: "닫기", follow: "소셜 미디어 팔로우", empty_msg: "장바구니가 비었습니다", settings_title: "설정", lang_label: "언어", save: "저장", settings_note: "선택이 자동으로 저장됩니다", alert_empty: "⚠️ 먼저 장바구니에 제품을 담아주세요!", alert_info: "⚠️ 배송 정보를 모두 입력해 주세요!", order_title: "🛒 Taourirt Bio 웹사이트 신규 주문 🛒", products: "제품", total_label: "합계", shipping_msg: "수량에 따라 다름", n_oil1: "타우리르트 올리브 오일 1L", n_oil5: "타우리르트 올리브 오일 5L", n_honey1: "타우리르트 꿀 1L", n_honey5: "타우리르트 꿀 5L", dir: "ltr", lang: "ko" },
  tr: { headline: "Taourirt'in Doğal ve Otantik Ürünleri | Taourirt Bio", oil: "Sızma Zeytinyağı - Taourirt ürünü", honey: "Doğal Bal - Taourirt ürünü", l1: "1 Litre", l5: "5 Litre", add: "Sepete ekle", cart: "Alışveriş Sepeti", total: "Toplam", name: "Tam ad", phone: "Telefon numarası", country: "Ülke", city: "Şehir", addr: "Tam adres (mahalle, cadde, sokak, no...)", shipping_label: "Teslimat ücreti (miktara göre)", confirm: "WhatsApp ile onayla", empty: "Sepeti boşalt", nav_oil: "Zeytinyağı", nav_honey: "Bal", nav_contact: "İletişim", nav_settings: "Ayarlar", contact: "Bize Ulaşın", wa_direct: "Direkt WhatsApp", close: "Kapat", follow: "Sosyal medyada bizi takip edin", empty_msg: "Sepet boş", settings_title: "Ayarlar", lang_label: "Dil", save: "Kaydet", settings_note: "Seçiminiz otomatik olarak kaydedilir", alert_empty: "⚠️ Lütfen önce sepete ürün ekleyin!", alert_info: "⚠️ Lütfen tüm teslimat bilgilerini doldurun!", order_title: "🛒 Taourirt Bio web sitesinden yeni sipariş 🛒", products: "Ürünler", total_label: "Toplam", shipping_msg: "Miktara göre değişir", n_oil1: "Taourirt Zeytinyağı 1L", n_oil5: "Taourirt Zeytinyağı 5L", n_honey1: "Taourirt Bal 1L", n_honey5: "Taourirt Bal 5L", dir: "ltr", lang: "tr" },
  it: { headline: "Prodotti Naturali Autentici di Taourirt | Taourirt Bio", oil: "Olio d'oliva extra vergine - prodotto di Taourirt", honey: "Miele naturale - prodotto di Taourirt", l1: "1 Litro", l5: "5 Litri", add: "Aggiungi al carrello", cart: "Carrello", total: "Totale", name: "Nome completo", phone: "Numero di telefono", country: "Paese", city: "Città", addr: "Indirizzo completo (quartiere, via, numero civico...)", shipping_label: "Costo di spedizione (in base alla quantità)", confirm: "Conferma ordine via WhatsApp", empty: "Svuota carrello", nav_oil: "Olio d'oliva", nav_honey: "Miele", nav_contact: "Contattaci", nav_settings: "Impostazioni", contact: "Contattaci", wa_direct: "WhatsApp diretto", close: "Chiudi", follow: "Seguici sui social", empty_msg: "Il carrello è vuoto", settings_title: "Impostazioni", lang_label: "Lingua", save: "Salva", settings_note: "La tua scelta viene salvata automaticamente", alert_empty: "⚠️ Aggiungi prima i prodotti al carrello!", alert_info: "⚠️ Compila tutte le informazioni di consegna!", order_title: "🛒 Nuovo ordine dal sito Taourirt Bio | Taourirt Bio 🛒", products: "Prodotti", total_label: "Totale", shipping_msg: "In base alla quantità", n_oil1: "Olio d'oliva di Taourirt 1L", n_oil5: "Olio d'oliva di Taourirt 5L", n_honey1: "Miele di Taourirt 1L", n_honey5: "Miele di Taourirt 5L", dir: "ltr", lang: "it" }
};

const _mem = {};
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return (k in _mem) ? _mem[k] : null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { _mem[k] = v; } }
};
let cur = store.get('lang') || 'ar';
let cart = [];
try { cart = JSON.parse(store.get('cart')) || []; } catch (e) { cart = []; }
if (!Array.isArray(cart)) cart = [];
let sum = cart.reduce((acc, item) => acc + item.price, 0);

function setText(id, txt) { const el = document.getElementById(id); if (el) el.textContent = txt; }
function setPH(id, txt) { const el = document.getElementById(id); if (el) el.placeholder = txt; }
function updateCartCount() { const badge = document.getElementById('cartCountBadge'); if (badge) badge.textContent = cart.length; }

function applyLang() {
    const d = T[cur] || T.ar;
    document.documentElement.lang = d.lang || 'ar';
    document.body.dir = d.dir || 'rtl';
    document.getElementById('mainHeadline').textContent = d.headline;
    setText('t_oil', d.oil);
    setText('t_honey', d.honey);
    setText('t_l1_oil', d.l1);
    setText('t_l5_oil', d.l5);
    setText('t_l1_honey', d.l1);
    setText('t_l5_honey', d.l5);
    setText('t_add_oil1', d.add);
    setText('t_add_oil5', d.add);
    setText('t_add_honey1', d.add);
    setText('t_add_honey5', d.add);
    setText('t_cart', d.cart);
    setText('t_total', d.total);
    setText('t_confirm', d.confirm);
    setText('t_empty', d.empty);
    setText('t_nav_oil', d.nav_oil);
    setText('t_nav_honey', d.nav_honey);
    setText('t_nav_contact', d.nav_contact);
    setText('t_nav_settings', d.nav_settings);
    setText('t_contact', d.contact);
    setText('t_wa_direct', d.wa_direct);
    setText('t_close', d.close);
    setText('t_follow', d.follow);
    setText('t_settings_title', d.settings_title);
    setText('t_lang_label', d.lang_label);
    setText('t_save', d.save);
    setText('t_settings_note', d.settings_note);
    setPH('name', d.name);
    setPH('phone', d.phone);
    setPH('country', d.country);
    setPH('city', d.city);
    setPH('addr', d.addr);
    const shippingField = document.getElementById('shipping');
    if (shippingField) { shippingField.value = d.shipping_msg; }
    document.getElementById('langSel').value = cur;
    renderCart();
}

function saveCart() { store.set('cart', JSON.stringify(cart)); updateCartCount(); }
function add(code, price) { cart.push({ code, price }); sum += price; renderCart(); saveCart(); }
function del(i) { sum -= cart[i].price; cart.splice(i, 1); renderCart(); saveCart(); }
function clearCart() { cart = []; sum = 0; renderCart(); saveCart(); }

function renderCart() {
    const listDiv = document.getElementById('list');
    const emptyWrapper = document.getElementById('emptyCartUnderIcon');
    const emptyTextSpan = document.getElementById('emptyCartText');
    const d = T[cur] || T.ar;
    if (cart.length === 0) {
        if (emptyTextSpan) emptyTextSpan.textContent = d.empty_msg;
        if (emptyWrapper) emptyWrapper.style.display = 'flex';
        listDiv.innerHTML = '';
    } else {
        if (emptyWrapper) emptyWrapper.style.display = 'none';
        listDiv.innerHTML = '';
        cart.forEach((it, i) => {
            let key = '';
            if (it.code === 'OIL_1L') key = 'n_oil1';
            else if (it.code === 'OIL_5L') key = 'n_oil5';
            else if (it.code === 'HONEY_1L') key = 'n_honey1';
            else if (it.code === 'HONEY_5L') key = 'n_honey5';
            const name = d[key] || it.code;
            const row = document.createElement('div');
            row.className = 'row';
            row.innerHTML = `<div>${name} - ${it.price} DH</div><button class="del" onclick="del(${i})"><i class="fa-solid fa-trash-can"></i></button>`;
            listDiv.appendChild(row);
        });
    }
    document.getElementById('sum').textContent = sum;
    updateCartCount();
}

function sendWA() {
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const country = document.getElementById('country').value.trim();
    const city = document.getElementById('city').value.trim();
    const addr = document.getElementById('addr').value.trim();
    const shippingValue = document.getElementById('shipping').value.trim();
    const d = T[cur] || T.ar;
    if (cart.length === 0) { alert(d.alert_empty); return; }
    if (!name || !phone || !country || !city || !addr) { alert(d.alert_info); return; }
    const productNames = { OIL_1L: d.n_oil1, OIL_5L: d.n_oil5, HONEY_1L: d.n_honey1, HONEY_5L: d.n_honey5 };
    let msg = `${d.order_title}\n\n`;
    msg += `👤 *${d.name}:* ${name}\n📞 *${d.phone}:* ${phone}\n🌍 *${d.country}:* ${country}\n🏙️ *${d.city}:* ${city}\n📍 *${d.addr}:* ${addr}\n\n📦 *${d.products}:*\n`;
    cart.forEach((it, idx) => { msg += `${idx+1}. ${productNames[it.code] || it.code} - ${it.price} DH\n`; });
    msg += `\n💰 *${d.total_label}:* ${sum} DH\n🚚 *${d.shipping_label}:* ${shippingValue}\n\n🔗 ${window.location.href}`;
    window.open('https://wa.me/212631599372?text=' + encodeURIComponent(msg), '_blank');
}

function openContact() { document.getElementById('contactModal').classList.add('show'); }
function closeContact() { document.getElementById('contactModal').classList.remove('show'); }
function openSettings() { document.getElementById('settingsModal').classList.add('show'); }
function closeSettings() { document.getElementById('settingsModal').classList.remove('show'); }

document.getElementById('langSel').addEventListener('change', function() { cur = this.value; store.set('lang', cur); applyLang(); });
applyLang();
