/* ===== حركة إضافة المنتوج إلى السلة (لا تغيّر منطق السلة) ===== */
(function(){
  const MSG={
    ar:["✓ تمت إضافة المنتوج إلى السلة بنجاح!","تمت الإضافة ✓"],
    en:["✓ Product added to cart successfully!","Added Successfully ✓"],
    fr:["✓ Produit ajouté au panier avec succès !","Ajouté avec succès ✓"],
    de:["✓ Produkt erfolgreich zum Warenkorb hinzugefügt!","Erfolgreich hinzugefügt ✓"],
    es:["✓ ¡Producto añadido al carrito con éxito!","Añadido con éxito ✓"],
    ru:["✓ Товар успешно добавлен в корзину!","Успешно добавлено ✓"],
    zh:["✓ 商品已成功加入购物车！","添加成功 ✓"],
    ko:["✓ 상품이 장바구니에 담겼습니다!","담기 완료 ✓"],
    tr:["✓ Ürün sepete başarıyla eklendi!","Başarıyla eklendi ✓"],
    it:["✓ Prodotto aggiunto al carrello con successo!","Aggiunto con successo ✓"]
  };
  const reduce=window.matchMedia('(prefers-reduced-motion: reduce)');
  const DURATION=850, MAX_FLIGHTS=6;
  let active=0, toastTimer=null;
  const msg=()=>MSG[(typeof cur!=='undefined'&&MSG[cur])?cur:'ar'];

  const toast=document.createElement('div');
  toast.className='cart-toast';toast.setAttribute('role','status');toast.setAttribute('aria-live','polite');
  document.body.appendChild(toast);
  function showToast(){
    toast.textContent=msg()[0];
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer=setTimeout(()=>toast.classList.remove('show'),2500);
  }

  function btnFeedback(btn){
    btn.classList.add('is-pressed');
    setTimeout(()=>btn.classList.remove('is-pressed'),140);
    const ok=msg()[1];
    if(btn.dataset.addedTimer){clearTimeout(+btn.dataset.addedTimer);}
    else{btn.dataset.orig=btn.textContent;}
    btn.textContent=ok;btn.classList.add('is-added');
    btn.dataset.addedTimer=setTimeout(()=>{
      if(btn.textContent===ok) btn.textContent=btn.dataset.orig;
      btn.classList.remove('is-added');
      delete btn.dataset.addedTimer;delete btn.dataset.orig;
    },1400);
  }

  function cartTarget(){
    const el=document.querySelector('.cart-icon-wrapper svg')||document.querySelector('.cart-icon-wrapper');
    if(!el) return null;
    const r=el.getBoundingClientRect();
    let x=r.left+r.width/2, y=r.top+r.height/2;
    const vw=document.documentElement.clientWidth, vh=window.innerHeight;
    x=Math.min(Math.max(x,20),vw-20);          // إن كانت السلة خارج الشاشة نطير نحو حافتها
    y=Math.min(Math.max(y,20),vh-20);
    return {x,y};
  }

  function cartReact(){
    const wrap=document.querySelector('.cart-icon-wrapper');
    const svg=wrap&&wrap.querySelector('svg');
    const badge=document.getElementById('cartCountBadge');
    if(reduce.matches) return;
    if(svg){
      svg.animate([
        {transform:'scale(1)',filter:'drop-shadow(0 3px 6px rgba(0,0,0,.3))'},
        {transform:'scale(1.18)',filter:'drop-shadow(0 0 16px rgba(212,175,55,.95))',offset:.35},
        {transform:'scale(.95)',offset:.65},
        {transform:'scale(1)',filter:'drop-shadow(0 3px 6px rgba(0,0,0,.3))'}
      ],{duration:520,easing:'ease-out'});
    }
    if(badge){
      badge.animate([{transform:'scale(1)'},{transform:'scale(1.55)',offset:.4},{transform:'scale(.88)',offset:.7},{transform:'scale(1)'}],{duration:480,easing:'cubic-bezier(.3,1.6,.5,1)'});
    }
  }

  function spawn(cls,size,x,y){
    const d=document.createElement('div');d.className=cls;
    d.style.width=d.style.height=size+'px';
    document.body.appendChild(d);return d;
  }

  function fly(img){
    const start=img.getBoundingClientRect();
    if(!start.width||!start.height) return;
    active++;
    const w=Math.min(start.width,170), h=start.height*(w/start.width);
    const clone=img.cloneNode(false);
    clone.removeAttribute('id');clone.className='fly-img';clone.setAttribute('aria-hidden','true');
    clone.style.width=w+'px';clone.style.height=h+'px';
    document.body.appendChild(clone);
    const sx=start.left+start.width/2, sy=start.top+start.height/2;
    const t0=performance.now();
    let lastTrail=0,lastSpark=0,sparks=0;
    const ease=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
    function frame(now){
      const p=Math.min((now-t0)/DURATION,1), e=ease(p);
      const tg=cartTarget()||{x:sx,y:sy-100};
      const cx=(sx+tg.x)/2+(tg.x<sx?-40:40), cy=Math.min(sy,tg.y)-Math.max(90,Math.abs(tg.y-sy)*.25);
      const u=1-e;
      const x=u*u*sx+2*u*e*cx+e*e*tg.x, y=u*u*sy+2*u*e*cy+e*e*tg.y;
      const sc=1-.82*e;
      clone.style.transform='translate('+(x-w/2)+'px,'+(y-h/2)+'px) scale('+sc+') rotate('+(e*14)+'deg)';
      clone.style.opacity=p>.85?String(1-(p-.85)/.15*.9):'1';
      if(p<.92){
        if(now-lastTrail>45){lastTrail=now;
          const sz=Math.max(14,w*sc*.5), g=spawn('fly-trail',sz);
          g.style.transform='translate('+(x-sz/2)+'px,'+(y-sz/2)+'px)';
          g.animate([{opacity:.7,transform:g.style.transform+' scale(1)'},{opacity:0,transform:g.style.transform+' scale(.3)'}],{duration:420,easing:'ease-out'}).onfinish=()=>g.remove();
        }
        if(now-lastSpark>110&&sparks<8){lastSpark=now;sparks++;
          const s=spawn('fly-spark',8+Math.random()*6);
          const ox=x+(Math.random()-.5)*w*sc, oy=y+(Math.random()-.5)*h*sc;
          const base='translate('+ox+'px,'+oy+'px)';
          s.animate([{opacity:1,transform:base+' scale(.4) rotate(0deg)'},{opacity:0,transform:'translate('+(ox+(Math.random()-.5)*34)+'px,'+(oy+10+Math.random()*22)+'px) scale(1.1) rotate(90deg)'}],{duration:520,easing:'ease-out'}).onfinish=()=>s.remove();
        }
      }
      if(p<1){requestAnimationFrame(frame);}
      else{clone.remove();active--;cartReact();}
    }
    requestAnimationFrame(frame);
  }

  document.addEventListener('click',function(ev){
    const btn=ev.target.closest&&ev.target.closest('button.buy');
    if(!btn) return;
    const oc=btn.getAttribute('onclick')||'';
    if(oc.indexOf('add(')!==0) return;           // أزرار الإضافة فقط
    try{
      btnFeedback(btn);
      showToast();
      const card=btn.closest('.card');
      const img=card&&card.querySelector('img');
      if(reduce.matches||!img||active>=MAX_FLIGHTS){ if(!reduce.matches) cartReact(); return; }
      fly(img);
    }catch(err){console.error('cart animation',err);}
  });
})();
